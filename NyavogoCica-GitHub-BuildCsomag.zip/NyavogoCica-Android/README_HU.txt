NYÁVOGÓ CICA – ANDROID STUDIO PROJEKT

Ez a teljes Android Studio projekt. Az alkalmazás helyi HTML-t használ,
ezért futás közben nem igényel internetkapcsolatot.

APK készítése:
1. Telepítsd az Android Studio-t egy számítógépre.
2. Csomagold ki a NyavogoCica-Android.zip fájlt.
3. Android Studio: Open, majd válaszd ki a NyavogoCica-Android mappát.
4. Várd meg a Gradle szinkronizálását és az Android SDK komponensek telepítését.
5. Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Az APK a következő helyen lesz: app/build/outputs/apk/debug/app-debug.apk

Funkciók:
- koppintásra mosoly és szintetizált nyávogás
- simogatásszámláló
- minden 10. koppintásnál 1 másodperces 360 fokos fordulat
- számláló nullázása
- offline működés

Követelmény: Android Studio, JDK 17 vagy újabb, Android SDK 35.
